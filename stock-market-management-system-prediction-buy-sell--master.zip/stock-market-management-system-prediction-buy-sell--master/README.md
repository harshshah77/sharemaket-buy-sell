# stock-market-management-system-prediction-buy-sell-
Stock market management system includes functionaliities like prediction (of next day's opening price) and buy-sell of stocks.

The index file is in
sms\RISE-Multipurpose html template\template-assets\index.php
location

This Website is hosted at www.hnksecurities.16mb.com 
